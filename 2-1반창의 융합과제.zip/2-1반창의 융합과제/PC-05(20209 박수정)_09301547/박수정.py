import random

class Organism:
    def __init__(self, gene):
        self.gene = gene  # 유전자 (0~1 사이의 값)
        self.fitness = 0  # 생존 가능성

    def calculate_fitness(self, environment):
        # 유전자와 환경에 따른 적합도 계산
        self.fitness = 1 - abs(self.gene - environment)

def simulate_generation(population_size, environment):
    # 개체군 생성
    population = [Organism(random.uniform(0, 1)) for _ in range(population_size)]
    
    # 적합도 계산
    for organism in population:
        organism.calculate_fitness(environment)
    
    # 자연선택에 따른 생존 개체 선택
    population.sort(key=lambda x: x.fitness, reverse=True)
    survivors = population[:population_size // 2]  # 상위 50% 생존
    
    # 다음 세대 생성
    next_generation = []
    for i in range(population_size):
        parent1 = random.choice(survivors)
        parent2 = random.choice(survivors)
        # 유전자의 평균을 통해 자식 생성
        child_gene = (parent1.gene + parent2.gene) / 2
        next_generation.append(Organism(child_gene))
    
    return next_generation

# 시뮬레이션 실행
generations = 10
population_size = 20
environment = 0.7  # 환경 기준값

population = [Organism(random.uniform(0, 1)) for _ in range(population_size)]

for generation in range(generations):
    population = simulate_generation(population_size, environment)
    avg_gene = sum(organism.gene for organism in population) / population_size
    print(f"Generation {generation + 1}: Average Gene = {avg_gene:.2f}")

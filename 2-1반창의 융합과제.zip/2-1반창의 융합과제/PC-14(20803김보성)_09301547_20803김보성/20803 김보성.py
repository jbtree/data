import http.client
import re

def simple_web_crawler(url, keyword):
    conn = http.client.HTTPSConnection("example.com")
    conn.request("GET", "/")
    #입력된 url로 부터 연결요청 보내기

    response = conn.getresponse()
    if response.status != 200:
        print("웹 페이지를 가져오는 데 실패했습니다.")
        return None, 0
    #응답코드가 200이 아니면 오류메세지 출력

    text = response.read().decode("utf-8")
    conn.close()
    #웹 페이지의 내용을 읽고 utf-8 문자열로 변형 및 연결 종료 

    words = re.findall(r'\b\w+\b', text)
    keyword_count = words.count(keyword)
    #표현식을 사용하여 텍스트에서 단어 추출 및 빈도 계산

    return text, keyword_count

url = 'https://example.com'
keyword = 'example'
#크롤링할 url 및 단어 선택

text_data, keyword_frequency = simple_web_crawler(url, keyword)
#크롤러 실행

if text_data:
    print("수집된 웹 페이지의 텍스트 데이터:\n", text_data[:500])
    print(f"키워드 '{keyword}'의 빈도 수:", keyword_frequency)
    #크롤러 출력

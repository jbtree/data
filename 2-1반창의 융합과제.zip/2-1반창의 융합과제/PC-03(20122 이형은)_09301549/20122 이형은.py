
def diode_bias(voltage):
    """
    다이오드의 바이어스 상태를 판단하는 함수
    :param voltage: 입력 전압 (V)
    :return: 다이오드 상태 (순방향 바이어스, 역방향 바이어스, 비정상)
    """
    if voltage > 0:
        return "순방향 바이어스"
    elif voltage < 0:
        return "역방향 바이어스"
    else:
        return "비정상 상태 (0V)"

# 사용자 입력 처리
try:
    voltage_input = float(input("전압 값을 입력하세요 (V): "))
    state = diode_bias(voltage_input)
    print(f"다이오드의 상태: {state}")
except ValueError:
    print("유효한 숫자를 입력하세요.")


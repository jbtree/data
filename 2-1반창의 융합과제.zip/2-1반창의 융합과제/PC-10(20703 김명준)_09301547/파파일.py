class ChernobylReactor:
    def __init__(self):
        self.power_level = 0
        self.coolant_temperature = 25
        self.control_rod_position = 100  # 0은 완전 삽입, 100은 완전 인출
        self.status = "정상 작동 중"

    def increase_power(self):
        if self.control_rod_position < 100:
            self.power_level += 10
            print("출력 증가: 현재 출력 수준은", self.power_level)
            self.check_explosion()  # 출력 증가 후 폭발 여부 체크
        else:
            print("제어봉이 완전히 삽입되어 출력 증가 불가.")

    def decrease_power(self):
        if self.power_level > 0:
            self.power_level -= 10
            print("출력 감소: 현재 출력 수준은", self.power_level)
        else:
            print("출력 수준이 이미 0입니다.")

    def insert_control_rod(self):
        if self.control_rod_position > 0:
            self.control_rod_position -= 10
            print("제어봉 삽입: 현재 제어봉 위치는", self.control_rod_position)
        else:
            print("제어봉이 완전히 삽입되었습니다.")

    def remove_control_rod(self):
        if self.control_rod_position < 100:
            self.control_rod_position += 10
            print("제어봉 인출: 현재 제어봉 위치는", self.control_rod_position)
        else:
            print("제어봉이 완전히 인출되었습니다.")

    def check_status(self):
        if self.power_level > 150:
            self.status = "위험: 과열 상태!"
        else:
            self.status = "정상 작동 중"
        print("원자로 상태:", self.status)

    def check_explosion(self):
        if self.power_level > 150:
            print("폭발! 원자로가 터졌습니다.")
            exit()  # 시뮬레이션 종료

    def run(self):
        while True:
            print("\n동작 키를 입력하세요: 1(출력 증가), 2(출력 감소), 3(제어봉 삽입), "
                  "4(제어봉 인출), 5(상태 점검), 6(종료)")
            choice = input("입력: ")

            if choice == '1':
                self.increase_power()
            elif choice == '2':
                self.decrease_power()
            elif choice == '3':
                self.insert_control_rod()
            elif choice == '4':
                self.remove_control_rod()
            elif choice == '5':
                self.check_status()
            elif choice == '6':
                print("시뮬레이션 종료.")
                break
            else:
                print("유효하지 않은 입력입니다.")

if __name__ == "__main__":
    reactor = ChernobylReactor()
    reactor.run()

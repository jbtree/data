from tkinter import *

buttons= [ '무염버터120g', '설탕90g', '박력분200g', '아몬드가루30g','베이킹파우더2g', '계란30g', '바닐라오일2g', '+', '총합', '삭제']


del clicky(key):

    if key == '총합':
        result = eval(e.get())
        s="=" + str(result)
        e.insert(END, s)
     elif key == '삭제':
         e.delete(0, END)
     elif (key == '박력분' or (key == '아몬드가루'):
         e.insert(END,"2g")
           

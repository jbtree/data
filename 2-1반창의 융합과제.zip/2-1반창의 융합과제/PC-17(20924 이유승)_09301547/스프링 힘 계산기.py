import tkinter as tk

def calculate_force():
    try:
        k = float(entry_k.get())
        x = float(entry_x.get())
        force = k * x
        label_result.config(text=f"힘 (F): {force:.2f} N")
    except ValueError:
        label_result.config(text="올바른 값을 입력하세요.")

# 기본 GUI 설정
root = tk.Tk()
root.title("스프링 힘 계산기")

# 스프링 상수 입력
label_k = tk.Label(root, text="스프링 상수 (k, N/m):")
label_k.pack()
entry_k = tk.Entry(root)
entry_k.pack()

# 변형량 입력
label_x = tk.Label(root, text="변형량 (x, m):")
label_x.pack()
entry_x = tk.Entry(root)
entry_x.pack()

# 계산 버튼
button_calculate = tk.Button(root, text="계산", command=calculate_force)
button_calculate.pack()

# 결과 표시
label_result = tk.Label(root, text="")
label_result.pack()

# GUI 실행
root.mainloop()

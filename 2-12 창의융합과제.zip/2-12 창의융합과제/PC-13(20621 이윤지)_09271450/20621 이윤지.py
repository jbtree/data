def main():
    user_input = input("청구 기호를 입력하세요 (예: 123 또는 123.4567): ")
    
    if (user_input.replace('.', '', 1).isdigit() and
            (len(user_input) == 3 or (len(user_input) > 3 and user_input[3] == '.' and len(user_input) <= 8))):
        number = float(user_input)
        
        if 0 <= number < 100:
            print(f"도서 {number}번은 [총류]에 있습니다.")
        elif 100<= number < 200:
            print(f"도서 {number}번은 [철학]에 있습니다.")
        elif 200<= number < 300:
            print(f"도서 {number}번은 [종교]에 있습니다.")
        elif 300<= number < 400:
            print(f"도서 {number}번은 [사회과학]에 있습니다.")
        elif 400<= number < 500:
            print(f"도서 {number}번은 [자연과학]에 있습니다.")
        elif 500<= number < 600:
            print(f"도서 {number}번은 [기술과학]에 있습니다.")
        elif 600<= number < 700:
            print(f"도서 {number}번은 [예술]에 있습니다.")
        elif 700<= number < 800:
            print(f"도서 {number}번은 [언어]에 있습니다.")
        elif 800<= number < 900:
            print(f"도서 {number}번은 [문학]에 있습니다.")
        else:
            print(f"도서 {number}번은 [역사]에 있습니다.")
    else:
        print("유효하지 않은 입력입니다. 세 자릿수 숫자를 입력하세요.")

if __name__ == "__main__":
    main()

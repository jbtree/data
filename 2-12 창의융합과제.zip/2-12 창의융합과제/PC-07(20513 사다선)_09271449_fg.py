import matplotlib.pyplot as plt

num_stars = int(input("몇 개의 별을 입력하시겠습니까? "))
a_m = []
s_t = []

for i in range(num_stars):
    a_m = float(input(f"별 {i + 1}의 절대 등급을 입력하세요: "))
    s_t = input(f"별 {i + 1}의 분광형을 입력하세요 (O, B, A, F, G, K, M): ").upper()
    
    a_m.append(a_m)
    s_t.append(s_t)

colors = {'O': 'blue','B': 'lightblue','A': 'white',
          'F': 'lightyellow','G': 'yellow','K': 'orange','M': 'red'}


star_colors = [colors.get(s_t, 'black') for s_t in s_t]


s_2 = {'O': 0, 'B': 1, 'A': 2, 'F': 3, 'G': 4, 'K': 5, 'M': 6}
x_values = [s_2.get(s_t, -1) for s_t in s_t]


plt.figure(figsize=(10, 6))
plt.scatter(x_values, a_m, color=star_colors, s=100)  
plt.xticks(list(s_2.values()), list(s_2.keys()))
plt.ylabel('분광형')
plt.title('H-R도')
plt.gca().invert_yaxis()  
plt.grid(True)
plt.show()

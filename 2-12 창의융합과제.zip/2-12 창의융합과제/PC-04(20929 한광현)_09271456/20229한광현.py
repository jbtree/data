
import re
from collections import defaultdict

class Molecule:
    def __init__(self, formula):
        self.formula = formula
        self.atom_count = self.count_atoms()
        self.polarity, self.bond_angle, self.shape = self.get_properties()

    def count_atoms(self):
        # 정규 표현식을 사용해 원자 수 세기
        pattern = r'([A-Z][a-z]*)(\d*)'
        atom_count = defaultdict(int)
        
        for (element, count) in re.findall(pattern, self.formula):
            count = int(count) if count else 1  # 기본값 1
            atom_count[element] += count
            
        return dict(atom_count)

    def get_properties(self):
        # 원자 종류와 수에 따른 변수 값 설정
        properties = {
            ('H', 2, 'O', 1): ("Polar", 104.5, "Bent"),  # 물 (H2O)
            ('C', 1, 'O', 2): ("Non-polar", 180, "Linear"),  # 이산화탄소 (CO2)
            ('N', 1, 'H', 3): ("Polar", 107.3, "Trigonal Pyramidal"),  # 암모니아 (NH3)
            ('C', 1, 'H', 4): ("Non-polar", 109.5, "Tetrahedral"),  # 메탄 (CH4)
            ('N', 2, 'H', 2): ("Polar", 104.5, "Bent"),  # 다이아민 (N2H2) 예시
        }

        # 입력된 원자 수에 따라 properties에서 정보 찾기
        for atoms, (polarity, bond_angle, shape) in properties.items():
            if all(self.atom_count.get(atom, 0) == count for atom, count in zip(atoms[::2], atoms[1::2])):
                return polarity, bond_angle, shape
        
        return "Unknown", 0, "Unknown"

    def __str__(self):
        atom_count_str = ', '.join(f"{atom}: {count}" for atom, count in self.atom_count.items())
        return (f"분자식: {self.formula}, 원자 수: {atom_count_str}, "
                f"극성: {self.polarity}, 결합각: {self.bond_angle}°, 결합 모양: {self.shape}")

# 빈 분자 목록 생성
molecules = []

# 사용자 입력 반복
while True:
    formula = input("분자의 화학식을 입력하세요 (종료하려면 'exit' 입력): ")
    if formula.lower() == 'exit':
        break
    
    # 원자 번호 20까지 제한 (H, He, Li, Be, B, C, N, O, F, Ne, Na, Mg, Al, Si, P, S, Cl, Ar, K, Ca)
    valid_atoms = set("H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca".split())
    atoms_in_formula = set(re.findall(r'[A-Z][a-z]*', formula))
    
    if not atoms_in_formula.issubset(valid_atoms):
        print("원자 번호는 20번까지의 원자로 제한됩니다. 다시 입력하세요.")
        continue
    
    # Molecule 객체 생성 후 리스트에 추가
    molecules.append(Molecule(formula))

# 분자 정보 출력
print("\n입력된 분자 정보:")
for molecule in molecules:
    print(molecule)

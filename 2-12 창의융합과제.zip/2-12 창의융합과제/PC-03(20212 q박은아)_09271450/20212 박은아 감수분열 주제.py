def simulate_meiosis_chromatids(initial_chromatids):
    """감수 분열을 염색 분체 수로 시뮬레이션하는 함수."""
    print("감수 분열 과정:")
    
    # 첫 번째 분열
    print(f"1단계 (전기 I, 중기 I, 후기 I, 말기 I): {initial_chromatids}개 염색 분체")
    
    # 첫 번째 분열 후 염색 분체 수 변화
    chromatids_after_first_division = initial_chromatids  # 염색 분체 수는 분열 전후로 변하지 않음
    print(f"첫 번째 분열 후: {chromatids_after_first_division}개 염색 분체 (각 세포당)")

    # 두 번째 분열
    print(f"2단계 (전기 II, 중기 II, 후기 II, 말기 II): {chromatids_after_first_division}개 염색 분체")
    
    # 두 번째 분열 후 염색 분체 수 변화
    chromatids_after_second_division = chromatids_after_first_division // 2
    print(f"두 번째 분열 후: {chromatids_after_second_division}개 염색 분체 (각 세포당)")

def main():
    print("감수 분열 염색 분체 시뮬레이터")
    
    # 초기 염색 분체 수 입력 받기
    initial_chromatids = int(input("초기 염색 분체 수를 입력하세요 (짝수): "))
    
    # 입력값 검증
    if initial_chromatids > 0 and initial_chromatids % 2 == 0:
        simulate_meiosis_chromatids(initial_chromatids)
    else:
        print("염색 분체 수는 2 이상의 짝수여야 합니다.")

if __name__ == "__main__":
    main()

def main():
    height=float(input("벽의 높이를 입력하세요(m):"))
    width=float(input("벽의 폭을 입력하세요(m):"))

    wall_area=height*width

    brick_area=0.2*0.1

    cement_per_sqm=10

    bricks_needed=wall_area / brick_area
    cement_needed=wall_area * cement_per_sqm

    print(f"벽면 면적:{wall_area:.2f}㎡")
    print(f"필요한 벽돌의 개수:{int(bricks_needed)}개")
    print(f"필요한 시멘트의 양:{cement_needed:.2f}㎏")

if __name__ =="__main__":
    main()

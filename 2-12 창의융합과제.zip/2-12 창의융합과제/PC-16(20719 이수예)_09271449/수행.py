from datetime import datetime, timedelta

def main():
    # 1) 에그 타르트의 소비 기간 (2일)
    shelf_life = timedelta(days=2)

    # 2) 에그 타르트를 산 날짜 입력 받기
    purchase_date_str = input("에그 타르트를 산 날짜를 입력하세요 (YYYY-MM-DD): ")
    
    # 3) 오늘 날짜 입력 받기
    today_date_str = input("오늘 날짜를 입력하세요 (YYYY-MM-DD): ")
    
    # 날짜 형식 변환
    purchase_date = datetime.strptime(purchase_date_str, "%Y-%m-%d")
    today_date = datetime.strptime(today_date_str, "%Y-%m-%d")
    
    # 4) 소비 기간을 고려하여 만료일 계산
    expiration_date = purchase_date + shelf_life

    # 5) 섭취 가능 여부 출력
    if today_date > expiration_date:
        print("에그 타르트는 섭취할 수 없습니다.")
    else:
        print("에그 타르트는 섭취할 수 있습니다.")

if __name__ == "__main__":
    main()






    
from datetime import datetime, timedelta

def main():
    # 냉장고 속 음식과 소비 기간 (현재 날짜로부터 계산)
    food_items = {
        "소고기": 5,      # 소비 기간 5일
        "숙주": 5,        # 소비 기간 5일
        "계란": 28,       # 소비 기간 4주 (28일)
        "초코우유": 10    # 소비 기간 10일
    }

    # 현재 날짜
    today = datetime.now()

    # 만료일 계산
    expiration_dates = {}
    for food, shelf_life in food_items.items():
        expiration_date = today + timedelta(days=shelf_life)
        expiration_dates[food] = expiration_date

    # 남은 소비 기간이 적은 순서로 정렬
    sorted_food_items = sorted(expiration_dates.items(), key=lambda item: item[1])

    print("\n소비 기간이 얼마 남지 않은 음식:")
    for food, expiration_date in sorted_food_items:
        remaining_days = (expiration_date - today).days
        if remaining_days >= 0:
            print(f"{food}: 남은 기간 {remaining_days}일 (만료일: {expiration_date.date()})")
        else:
            print(f"{food}: 이미 만료되었습니다. (만료일: {expiration_date.date()})")

if __name__ == "__main__":
    main()

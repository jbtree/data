vel=0
f=0
vel = int(input('탑승 차량의 최대 속력을 입력하세요:'))
rd = int(input('노면 상태를 입력하세요(건조하다(0)/습하다(1)):'))
if rd == 0:
    f = 1.2
else:
    f = 0.7
for i in range(1,vel+1):
    brd= 3.6/2.5*i
    bd = vel*vel/(2*9.8*3.6*3.6*f)
    


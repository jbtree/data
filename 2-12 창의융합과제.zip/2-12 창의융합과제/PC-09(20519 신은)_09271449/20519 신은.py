def calculate_gc_content(dna_s):
    g_count=dna_s.count('G')
    c_count=dna_s.count('C')
    total_count= len(dna_s)

    if total_count == 0:
        return 0.0
    gc_content= (g_count+c_count)/total_count * 100
    return gc_content

def main():
    dna_s = input('DNA 서열을 입력하세요:').upper()
    gc_content= calculate_gc_content(dna_s)

    print(f'GC 비율: {gc_content:.2f}%')

if __name__ == '__main__':
    main()
